# Parking-Software-C- "using c++"
c++ classes,
concept of composition,


this software generate a report of income at the end of day 
paying salaries to parking manager, security guards, and floor attendants persons
Although govt charges are being paid

in and out function for various vehicle,

when a vehicle comes for parking 
first i check that is there space for this vehicle for parking
if yes then allowing it otherwise not
when it leaves asking for charges and storing it in a variable 
