These are some codes for python beginners.
